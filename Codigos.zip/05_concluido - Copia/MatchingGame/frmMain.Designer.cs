﻿


namespace MatchingGame
{
    partial class frmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            button42 = new Button();
            button41 = new Button();
            button40 = new Button();
            button39 = new Button();
            button38 = new Button();
            button37 = new Button();
            button36 = new Button();
            button35 = new Button();
            button34 = new Button();
            button33 = new Button();
            button32 = new Button();
            button31 = new Button();
            button30 = new Button();
            button29 = new Button();
            button28 = new Button();
            button27 = new Button();
            button26 = new Button();
            button25 = new Button();
            button24 = new Button();
            button23 = new Button();
            button22 = new Button();
            button21 = new Button();
            button20 = new Button();
            button19 = new Button();
            button18 = new Button();
            button17 = new Button();
            button16 = new Button();
            button15 = new Button();
            button14 = new Button();
            button13 = new Button();
            button12 = new Button();
            button11 = new Button();
            button10 = new Button();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            menuStrip1 = new MenuStrip();
            button43 = new Button();
            label1 = new Label();
            label2 = new Label();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 7;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.28571F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.28571F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.28571F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.28571F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.28571F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.28571F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.28571F));
            tableLayoutPanel1.Controls.Add(button42, 6, 5);
            tableLayoutPanel1.Controls.Add(button41, 5, 5);
            tableLayoutPanel1.Controls.Add(button40, 4, 5);
            tableLayoutPanel1.Controls.Add(button39, 3, 5);
            tableLayoutPanel1.Controls.Add(button38, 2, 5);
            tableLayoutPanel1.Controls.Add(button37, 1, 5);
            tableLayoutPanel1.Controls.Add(button36, 0, 5);
            tableLayoutPanel1.Controls.Add(button35, 6, 4);
            tableLayoutPanel1.Controls.Add(button34, 5, 4);
            tableLayoutPanel1.Controls.Add(button33, 4, 4);
            tableLayoutPanel1.Controls.Add(button32, 3, 4);
            tableLayoutPanel1.Controls.Add(button31, 2, 4);
            tableLayoutPanel1.Controls.Add(button30, 1, 4);
            tableLayoutPanel1.Controls.Add(button29, 0, 4);
            tableLayoutPanel1.Controls.Add(button28, 6, 3);
            tableLayoutPanel1.Controls.Add(button27, 5, 3);
            tableLayoutPanel1.Controls.Add(button26, 4, 3);
            tableLayoutPanel1.Controls.Add(button25, 3, 3);
            tableLayoutPanel1.Controls.Add(button24, 2, 3);
            tableLayoutPanel1.Controls.Add(button23, 1, 3);
            tableLayoutPanel1.Controls.Add(button22, 0, 3);
            tableLayoutPanel1.Controls.Add(button21, 6, 2);
            tableLayoutPanel1.Controls.Add(button20, 5, 2);
            tableLayoutPanel1.Controls.Add(button19, 4, 2);
            tableLayoutPanel1.Controls.Add(button18, 3, 2);
            tableLayoutPanel1.Controls.Add(button17, 2, 2);
            tableLayoutPanel1.Controls.Add(button16, 1, 2);
            tableLayoutPanel1.Controls.Add(button15, 0, 2);
            tableLayoutPanel1.Controls.Add(button14, 6, 1);
            tableLayoutPanel1.Controls.Add(button13, 5, 1);
            tableLayoutPanel1.Controls.Add(button12, 4, 1);
            tableLayoutPanel1.Controls.Add(button11, 3, 1);
            tableLayoutPanel1.Controls.Add(button10, 2, 1);
            tableLayoutPanel1.Controls.Add(button9, 1, 1);
            tableLayoutPanel1.Controls.Add(button8, 0, 1);
            tableLayoutPanel1.Controls.Add(button7, 6, 0);
            tableLayoutPanel1.Controls.Add(button6, 5, 0);
            tableLayoutPanel1.Controls.Add(button5, 4, 0);
            tableLayoutPanel1.Controls.Add(button4, 3, 0);
            tableLayoutPanel1.Controls.Add(button3, 2, 0);
            tableLayoutPanel1.Controls.Add(button2, 1, 0);
            tableLayoutPanel1.Controls.Add(button1, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 24);
            tableLayoutPanel1.Margin = new Padding(4, 3, 4, 3);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 6;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 16.66667F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 16.66667F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 16.66667F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 16.66667F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 16.66667F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 16.66667F));
            tableLayoutPanel1.Size = new Size(961, 694);
            tableLayoutPanel1.TabIndex = 2;
            // 
            // button42
            // 
            button42.BackColor = SystemColors.GradientActiveCaption;
            button42.BackgroundImageLayout = ImageLayout.Stretch;
            button42.Dock = DockStyle.Fill;
            button42.FlatStyle = FlatStyle.Flat;
            button42.Location = new Point(826, 578);
            button42.Margin = new Padding(4, 3, 4, 3);
            button42.Name = "button42";
            button42.Size = new Size(131, 113);
            button42.TabIndex = 41;
            button42.UseVisualStyleBackColor = false;
            button42.Click += button1_Click;
            // 
            // button41
            // 
            button41.BackColor = SystemColors.GradientActiveCaption;
            button41.BackgroundImageLayout = ImageLayout.Stretch;
            button41.Dock = DockStyle.Fill;
            button41.FlatStyle = FlatStyle.Flat;
            button41.Location = new Point(689, 578);
            button41.Margin = new Padding(4, 3, 4, 3);
            button41.Name = "button41";
            button41.Size = new Size(129, 113);
            button41.TabIndex = 40;
            button41.UseVisualStyleBackColor = false;
            button41.Click += button1_Click;
            // 
            // button40
            // 
            button40.BackColor = SystemColors.GradientActiveCaption;
            button40.BackgroundImageLayout = ImageLayout.Stretch;
            button40.Dock = DockStyle.Fill;
            button40.FlatStyle = FlatStyle.Flat;
            button40.Location = new Point(552, 578);
            button40.Margin = new Padding(4, 3, 4, 3);
            button40.Name = "button40";
            button40.Size = new Size(129, 113);
            button40.TabIndex = 39;
            button40.UseVisualStyleBackColor = false;
            button40.Click += button1_Click;
            // 
            // button39
            // 
            button39.BackColor = SystemColors.GradientActiveCaption;
            button39.BackgroundImageLayout = ImageLayout.Stretch;
            button39.Dock = DockStyle.Fill;
            button39.FlatStyle = FlatStyle.Flat;
            button39.Location = new Point(415, 578);
            button39.Margin = new Padding(4, 3, 4, 3);
            button39.Name = "button39";
            button39.Size = new Size(129, 113);
            button39.TabIndex = 38;
            button39.UseVisualStyleBackColor = false;
            button39.Click += button1_Click;
            // 
            // button38
            // 
            button38.BackColor = SystemColors.GradientActiveCaption;
            button38.BackgroundImageLayout = ImageLayout.Stretch;
            button38.Dock = DockStyle.Fill;
            button38.FlatStyle = FlatStyle.Flat;
            button38.Location = new Point(278, 578);
            button38.Margin = new Padding(4, 3, 4, 3);
            button38.Name = "button38";
            button38.Size = new Size(129, 113);
            button38.TabIndex = 37;
            button38.UseVisualStyleBackColor = false;
            button38.Click += button1_Click;
            // 
            // button37
            // 
            button37.BackColor = SystemColors.GradientActiveCaption;
            button37.BackgroundImageLayout = ImageLayout.Stretch;
            button37.Dock = DockStyle.Fill;
            button37.FlatStyle = FlatStyle.Flat;
            button37.Location = new Point(141, 578);
            button37.Margin = new Padding(4, 3, 4, 3);
            button37.Name = "button37";
            button37.Size = new Size(129, 113);
            button37.TabIndex = 36;
            button37.UseVisualStyleBackColor = false;
            button37.Click += button1_Click;
            // 
            // button36
            // 
            button36.BackColor = SystemColors.GradientActiveCaption;
            button36.BackgroundImageLayout = ImageLayout.Stretch;
            button36.Dock = DockStyle.Fill;
            button36.FlatStyle = FlatStyle.Flat;
            button36.Location = new Point(4, 578);
            button36.Margin = new Padding(4, 3, 4, 3);
            button36.Name = "button36";
            button36.Size = new Size(129, 113);
            button36.TabIndex = 35;
            button36.UseVisualStyleBackColor = false;
            button36.Click += button1_Click;
            // 
            // button35
            // 
            button35.BackColor = SystemColors.GradientActiveCaption;
            button35.BackgroundImageLayout = ImageLayout.Stretch;
            button35.Dock = DockStyle.Fill;
            button35.FlatStyle = FlatStyle.Flat;
            button35.Location = new Point(826, 463);
            button35.Margin = new Padding(4, 3, 4, 3);
            button35.Name = "button35";
            button35.Size = new Size(131, 109);
            button35.TabIndex = 34;
            button35.UseVisualStyleBackColor = false;
            button35.Click += button1_Click;
            // 
            // button34
            // 
            button34.BackColor = SystemColors.GradientActiveCaption;
            button34.BackgroundImageLayout = ImageLayout.Stretch;
            button34.Dock = DockStyle.Fill;
            button34.FlatStyle = FlatStyle.Flat;
            button34.Location = new Point(689, 463);
            button34.Margin = new Padding(4, 3, 4, 3);
            button34.Name = "button34";
            button34.Size = new Size(129, 109);
            button34.TabIndex = 33;
            button34.UseVisualStyleBackColor = false;
            button34.Click += button1_Click;
            // 
            // button33
            // 
            button33.BackColor = SystemColors.GradientActiveCaption;
            button33.BackgroundImageLayout = ImageLayout.Stretch;
            button33.Dock = DockStyle.Fill;
            button33.FlatStyle = FlatStyle.Flat;
            button33.Location = new Point(552, 463);
            button33.Margin = new Padding(4, 3, 4, 3);
            button33.Name = "button33";
            button33.Size = new Size(129, 109);
            button33.TabIndex = 32;
            button33.UseVisualStyleBackColor = false;
            button33.Click += button1_Click;
            // 
            // button32
            // 
            button32.BackColor = SystemColors.GradientActiveCaption;
            button32.BackgroundImageLayout = ImageLayout.Stretch;
            button32.Dock = DockStyle.Fill;
            button32.FlatStyle = FlatStyle.Flat;
            button32.Location = new Point(415, 463);
            button32.Margin = new Padding(4, 3, 4, 3);
            button32.Name = "button32";
            button32.Size = new Size(129, 109);
            button32.TabIndex = 31;
            button32.UseVisualStyleBackColor = false;
            button32.Click += button1_Click;
            // 
            // button31
            // 
            button31.BackColor = SystemColors.GradientActiveCaption;
            button31.BackgroundImageLayout = ImageLayout.Stretch;
            button31.Dock = DockStyle.Fill;
            button31.FlatStyle = FlatStyle.Flat;
            button31.Location = new Point(278, 463);
            button31.Margin = new Padding(4, 3, 4, 3);
            button31.Name = "button31";
            button31.Size = new Size(129, 109);
            button31.TabIndex = 30;
            button31.UseVisualStyleBackColor = false;
            button31.Click += button1_Click;
            // 
            // button30
            // 
            button30.BackColor = SystemColors.GradientActiveCaption;
            button30.BackgroundImageLayout = ImageLayout.Stretch;
            button30.Dock = DockStyle.Fill;
            button30.FlatStyle = FlatStyle.Flat;
            button30.Location = new Point(141, 463);
            button30.Margin = new Padding(4, 3, 4, 3);
            button30.Name = "button30";
            button30.Size = new Size(129, 109);
            button30.TabIndex = 29;
            button30.UseVisualStyleBackColor = false;
            button30.Click += button1_Click;
            // 
            // button29
            // 
            button29.BackColor = SystemColors.GradientActiveCaption;
            button29.BackgroundImageLayout = ImageLayout.Stretch;
            button29.Dock = DockStyle.Fill;
            button29.FlatStyle = FlatStyle.Flat;
            button29.Location = new Point(4, 463);
            button29.Margin = new Padding(4, 3, 4, 3);
            button29.Name = "button29";
            button29.Size = new Size(129, 109);
            button29.TabIndex = 28;
            button29.UseVisualStyleBackColor = false;
            button29.Click += button1_Click;
            // 
            // button28
            // 
            button28.BackColor = SystemColors.GradientActiveCaption;
            button28.BackgroundImageLayout = ImageLayout.Stretch;
            button28.Dock = DockStyle.Fill;
            button28.FlatStyle = FlatStyle.Flat;
            button28.Location = new Point(826, 348);
            button28.Margin = new Padding(4, 3, 4, 3);
            button28.Name = "button28";
            button28.Size = new Size(131, 109);
            button28.TabIndex = 27;
            button28.UseVisualStyleBackColor = false;
            button28.Click += button1_Click;
            // 
            // button27
            // 
            button27.BackColor = SystemColors.GradientActiveCaption;
            button27.BackgroundImageLayout = ImageLayout.Stretch;
            button27.Dock = DockStyle.Fill;
            button27.FlatStyle = FlatStyle.Flat;
            button27.Location = new Point(689, 348);
            button27.Margin = new Padding(4, 3, 4, 3);
            button27.Name = "button27";
            button27.Size = new Size(129, 109);
            button27.TabIndex = 26;
            button27.UseVisualStyleBackColor = false;
            button27.Click += button1_Click;
            // 
            // button26
            // 
            button26.BackColor = SystemColors.GradientActiveCaption;
            button26.BackgroundImageLayout = ImageLayout.Stretch;
            button26.Dock = DockStyle.Fill;
            button26.FlatStyle = FlatStyle.Flat;
            button26.Location = new Point(552, 348);
            button26.Margin = new Padding(4, 3, 4, 3);
            button26.Name = "button26";
            button26.Size = new Size(129, 109);
            button26.TabIndex = 25;
            button26.UseVisualStyleBackColor = false;
            button26.Click += button1_Click;
            // 
            // button25
            // 
            button25.BackColor = SystemColors.GradientActiveCaption;
            button25.BackgroundImageLayout = ImageLayout.Stretch;
            button25.Dock = DockStyle.Fill;
            button25.FlatStyle = FlatStyle.Flat;
            button25.Location = new Point(415, 348);
            button25.Margin = new Padding(4, 3, 4, 3);
            button25.Name = "button25";
            button25.Size = new Size(129, 109);
            button25.TabIndex = 24;
            button25.UseVisualStyleBackColor = false;
            button25.Click += button1_Click;
            // 
            // button24
            // 
            button24.BackColor = SystemColors.GradientActiveCaption;
            button24.BackgroundImageLayout = ImageLayout.Stretch;
            button24.Dock = DockStyle.Fill;
            button24.FlatStyle = FlatStyle.Flat;
            button24.Location = new Point(278, 348);
            button24.Margin = new Padding(4, 3, 4, 3);
            button24.Name = "button24";
            button24.Size = new Size(129, 109);
            button24.TabIndex = 23;
            button24.UseVisualStyleBackColor = false;
            button24.Click += button1_Click;
            // 
            // button23
            // 
            button23.BackColor = SystemColors.GradientActiveCaption;
            button23.BackgroundImageLayout = ImageLayout.Stretch;
            button23.Dock = DockStyle.Fill;
            button23.FlatStyle = FlatStyle.Flat;
            button23.Location = new Point(141, 348);
            button23.Margin = new Padding(4, 3, 4, 3);
            button23.Name = "button23";
            button23.Size = new Size(129, 109);
            button23.TabIndex = 22;
            button23.UseVisualStyleBackColor = false;
            button23.Click += button1_Click;
            // 
            // button22
            // 
            button22.BackColor = SystemColors.GradientActiveCaption;
            button22.BackgroundImageLayout = ImageLayout.Stretch;
            button22.Dock = DockStyle.Fill;
            button22.FlatStyle = FlatStyle.Flat;
            button22.Location = new Point(4, 348);
            button22.Margin = new Padding(4, 3, 4, 3);
            button22.Name = "button22";
            button22.Size = new Size(129, 109);
            button22.TabIndex = 21;
            button22.UseVisualStyleBackColor = false;
            button22.Click += button1_Click;
            // 
            // button21
            // 
            button21.BackColor = SystemColors.GradientActiveCaption;
            button21.BackgroundImageLayout = ImageLayout.Stretch;
            button21.Dock = DockStyle.Fill;
            button21.FlatStyle = FlatStyle.Flat;
            button21.Location = new Point(826, 233);
            button21.Margin = new Padding(4, 3, 4, 3);
            button21.Name = "button21";
            button21.Size = new Size(131, 109);
            button21.TabIndex = 20;
            button21.UseVisualStyleBackColor = false;
            button21.Click += button1_Click;
            // 
            // button20
            // 
            button20.BackColor = SystemColors.GradientActiveCaption;
            button20.BackgroundImageLayout = ImageLayout.Stretch;
            button20.Dock = DockStyle.Fill;
            button20.FlatStyle = FlatStyle.Flat;
            button20.Location = new Point(689, 233);
            button20.Margin = new Padding(4, 3, 4, 3);
            button20.Name = "button20";
            button20.Size = new Size(129, 109);
            button20.TabIndex = 19;
            button20.UseVisualStyleBackColor = false;
            button20.Click += button1_Click;
            // 
            // button19
            // 
            button19.BackColor = SystemColors.GradientActiveCaption;
            button19.BackgroundImageLayout = ImageLayout.Stretch;
            button19.Dock = DockStyle.Fill;
            button19.FlatStyle = FlatStyle.Flat;
            button19.Location = new Point(552, 233);
            button19.Margin = new Padding(4, 3, 4, 3);
            button19.Name = "button19";
            button19.Size = new Size(129, 109);
            button19.TabIndex = 18;
            button19.UseVisualStyleBackColor = false;
            button19.Click += button1_Click;
            // 
            // button18
            // 
            button18.BackColor = SystemColors.GradientActiveCaption;
            button18.BackgroundImageLayout = ImageLayout.Stretch;
            button18.Dock = DockStyle.Fill;
            button18.FlatStyle = FlatStyle.Flat;
            button18.Location = new Point(415, 233);
            button18.Margin = new Padding(4, 3, 4, 3);
            button18.Name = "button18";
            button18.Size = new Size(129, 109);
            button18.TabIndex = 17;
            button18.UseVisualStyleBackColor = false;
            button18.Click += button1_Click;
            // 
            // button17
            // 
            button17.BackColor = SystemColors.GradientActiveCaption;
            button17.BackgroundImageLayout = ImageLayout.Stretch;
            button17.Dock = DockStyle.Fill;
            button17.FlatStyle = FlatStyle.Flat;
            button17.Location = new Point(278, 233);
            button17.Margin = new Padding(4, 3, 4, 3);
            button17.Name = "button17";
            button17.Size = new Size(129, 109);
            button17.TabIndex = 16;
            button17.UseVisualStyleBackColor = false;
            button17.Click += button1_Click;
            // 
            // button16
            // 
            button16.BackColor = SystemColors.GradientActiveCaption;
            button16.BackgroundImageLayout = ImageLayout.Stretch;
            button16.Dock = DockStyle.Fill;
            button16.FlatStyle = FlatStyle.Flat;
            button16.Location = new Point(141, 233);
            button16.Margin = new Padding(4, 3, 4, 3);
            button16.Name = "button16";
            button16.Size = new Size(129, 109);
            button16.TabIndex = 15;
            button16.UseVisualStyleBackColor = false;
            button16.Click += button1_Click;
            // 
            // button15
            // 
            button15.BackColor = SystemColors.GradientActiveCaption;
            button15.BackgroundImageLayout = ImageLayout.Stretch;
            button15.Dock = DockStyle.Fill;
            button15.FlatStyle = FlatStyle.Flat;
            button15.Location = new Point(4, 233);
            button15.Margin = new Padding(4, 3, 4, 3);
            button15.Name = "button15";
            button15.Size = new Size(129, 109);
            button15.TabIndex = 14;
            button15.UseVisualStyleBackColor = false;
            button15.Click += button1_Click;
            // 
            // button14
            // 
            button14.BackColor = SystemColors.GradientActiveCaption;
            button14.BackgroundImageLayout = ImageLayout.Stretch;
            button14.Dock = DockStyle.Fill;
            button14.FlatStyle = FlatStyle.Flat;
            button14.Location = new Point(826, 118);
            button14.Margin = new Padding(4, 3, 4, 3);
            button14.Name = "button14";
            button14.Size = new Size(131, 109);
            button14.TabIndex = 13;
            button14.UseVisualStyleBackColor = false;
            button14.Click += button1_Click;
            // 
            // button13
            // 
            button13.BackColor = SystemColors.GradientActiveCaption;
            button13.BackgroundImageLayout = ImageLayout.Stretch;
            button13.Dock = DockStyle.Fill;
            button13.FlatStyle = FlatStyle.Flat;
            button13.Location = new Point(689, 118);
            button13.Margin = new Padding(4, 3, 4, 3);
            button13.Name = "button13";
            button13.Size = new Size(129, 109);
            button13.TabIndex = 12;
            button13.UseVisualStyleBackColor = false;
            button13.Click += button1_Click;
            // 
            // button12
            // 
            button12.BackColor = SystemColors.GradientActiveCaption;
            button12.BackgroundImageLayout = ImageLayout.Stretch;
            button12.Dock = DockStyle.Fill;
            button12.FlatStyle = FlatStyle.Flat;
            button12.Location = new Point(552, 118);
            button12.Margin = new Padding(4, 3, 4, 3);
            button12.Name = "button12";
            button12.Size = new Size(129, 109);
            button12.TabIndex = 11;
            button12.UseVisualStyleBackColor = false;
            button12.Click += button1_Click;
            // 
            // button11
            // 
            button11.BackColor = SystemColors.GradientActiveCaption;
            button11.BackgroundImageLayout = ImageLayout.Stretch;
            button11.Dock = DockStyle.Fill;
            button11.FlatStyle = FlatStyle.Flat;
            button11.Location = new Point(415, 118);
            button11.Margin = new Padding(4, 3, 4, 3);
            button11.Name = "button11";
            button11.Size = new Size(129, 109);
            button11.TabIndex = 10;
            button11.UseVisualStyleBackColor = false;
            button11.Click += button1_Click;
            // 
            // button10
            // 
            button10.BackColor = SystemColors.GradientActiveCaption;
            button10.BackgroundImageLayout = ImageLayout.Stretch;
            button10.Dock = DockStyle.Fill;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Location = new Point(278, 118);
            button10.Margin = new Padding(4, 3, 4, 3);
            button10.Name = "button10";
            button10.Size = new Size(129, 109);
            button10.TabIndex = 9;
            button10.UseVisualStyleBackColor = false;
            button10.Click += button1_Click;
            // 
            // button9
            // 
            button9.BackColor = SystemColors.GradientActiveCaption;
            button9.BackgroundImageLayout = ImageLayout.Stretch;
            button9.Dock = DockStyle.Fill;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Location = new Point(141, 118);
            button9.Margin = new Padding(4, 3, 4, 3);
            button9.Name = "button9";
            button9.Size = new Size(129, 109);
            button9.TabIndex = 8;
            button9.UseVisualStyleBackColor = false;
            button9.Click += button1_Click;
            // 
            // button8
            // 
            button8.BackColor = SystemColors.GradientActiveCaption;
            button8.BackgroundImageLayout = ImageLayout.Stretch;
            button8.Dock = DockStyle.Fill;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Location = new Point(4, 118);
            button8.Margin = new Padding(4, 3, 4, 3);
            button8.Name = "button8";
            button8.Size = new Size(129, 109);
            button8.TabIndex = 7;
            button8.UseVisualStyleBackColor = false;
            button8.Click += button1_Click;
            // 
            // button7
            // 
            button7.BackColor = SystemColors.GradientActiveCaption;
            button7.BackgroundImageLayout = ImageLayout.Stretch;
            button7.Dock = DockStyle.Fill;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Location = new Point(826, 3);
            button7.Margin = new Padding(4, 3, 4, 3);
            button7.Name = "button7";
            button7.Size = new Size(131, 109);
            button7.TabIndex = 6;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button1_Click;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.GradientActiveCaption;
            button6.BackgroundImageLayout = ImageLayout.Stretch;
            button6.Dock = DockStyle.Fill;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Location = new Point(689, 3);
            button6.Margin = new Padding(4, 3, 4, 3);
            button6.Name = "button6";
            button6.Size = new Size(129, 109);
            button6.TabIndex = 5;
            button6.UseVisualStyleBackColor = false;
            button6.Click += button1_Click;
            // 
            // button5
            // 
            button5.BackColor = SystemColors.GradientActiveCaption;
            button5.BackgroundImageLayout = ImageLayout.Stretch;
            button5.Dock = DockStyle.Fill;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Location = new Point(552, 3);
            button5.Margin = new Padding(4, 3, 4, 3);
            button5.Name = "button5";
            button5.Size = new Size(129, 109);
            button5.TabIndex = 4;
            button5.UseVisualStyleBackColor = false;
            button5.Click += button1_Click;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.GradientActiveCaption;
            button4.BackgroundImageLayout = ImageLayout.Stretch;
            button4.Dock = DockStyle.Fill;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Location = new Point(415, 3);
            button4.Margin = new Padding(4, 3, 4, 3);
            button4.Name = "button4";
            button4.Size = new Size(129, 109);
            button4.TabIndex = 3;
            button4.UseVisualStyleBackColor = false;
            button4.Click += button1_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.GradientActiveCaption;
            button3.BackgroundImageLayout = ImageLayout.Stretch;
            button3.Dock = DockStyle.Fill;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Location = new Point(278, 3);
            button3.Margin = new Padding(4, 3, 4, 3);
            button3.Name = "button3";
            button3.Size = new Size(129, 109);
            button3.TabIndex = 2;
            button3.UseVisualStyleBackColor = false;
            button3.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.GradientActiveCaption;
            button2.BackgroundImageLayout = ImageLayout.Stretch;
            button2.Dock = DockStyle.Fill;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Location = new Point(141, 3);
            button2.Margin = new Padding(4, 3, 4, 3);
            button2.Name = "button2";
            button2.Size = new Size(129, 109);
            button2.TabIndex = 1;
            button2.UseVisualStyleBackColor = false;
            button2.Click += button1_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.GradientActiveCaption;
            button1.BackgroundImageLayout = ImageLayout.Stretch;
            button1.Dock = DockStyle.Fill;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Location = new Point(4, 3);
            button1.Margin = new Padding(4, 3, 4, 3);
            button1.Name = "button1";
            button1.Size = new Size(129, 109);
            button1.TabIndex = 0;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(7, 2, 0, 2);
            menuStrip1.Size = new Size(961, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            menuStrip1.ItemClicked += menuStrip1_ItemClicked;
            // 
            // button43
            // 
            button43.Location = new Point(5, 0);
            button43.Name = "button43";
            button43.Size = new Size(79, 22);
            button43.TabIndex = 3;
            button43.Text = "Voltar";
            button43.UseVisualStyleBackColor = true;
            button43.Click += button43_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(891, 4);
            label1.Name = "label1";
            label1.Size = new Size(0, 15);
            label1.TabIndex = 4;
           
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Cursor = Cursors.No;
            label2.Location = new Point(441, 4);
            label2.Name = "label2";
            label2.Size = new Size(67, 15);
            label2.TabIndex = 5;
            label2.Text = "Pontuação:";
           
            // 
            // frmMain
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(961, 718);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button43);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(4, 3, 4, 3);
            Name = "frmMain";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Jogo de Correspondência";
            Load += frmMain_Load;
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private MenuStrip menuStrip1;
        private Button button43;
        private Label label1;
        private Label label2;
    }
}
